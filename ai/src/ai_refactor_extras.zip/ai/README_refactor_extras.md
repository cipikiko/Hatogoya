# ai/src refactor (extra scripts)

Refactored into focused subpackages:

- `ai.src.dataio` — data building & converters
  - `hdf5_builder.py`
  - `plantnet_to_hdf5.py`
  - `plantnet_to_hdf5_encoded.py`

- `ai.src.datasets` — dataset definitions
  - `hdf5_dataset.py`
  - `hdf5_dataset_bytes.py`

- `ai.src.runtime` — runtime helpers
  - `cuda_prefetcher.py`

- `ai.src.inference` — export & client utilities
  - `export_onnx.py`
  - `infer_client.py`

- `ai.src.evals` — evaluation/reporting
  - `eval.py`
  - `eval_report.py`

- `ai.src.viz` — plotting & figures
  - `plot_training.py`

## Running as modules

```bash
# Export to ONNX
python -m ai.src.inference.export_onnx --help

# Evaluate
python -m ai.src.evals.eval --help
python -m ai.src.evals.eval_report --help

# Build HDF5
python -m ai.src.dataio.hdf5_builder --help
python -m ai.src.dataio.plantnet_to_hdf5 --help
python -m ai.src.dataio.plantnet_to_hdf5_encoded --help

# Plot
python -m ai.src.viz.plot_training --help

# Inference client
python -m ai.src.inference.infer_client --help
```

Ensure the parent of `ai/` is on PYTHONPATH (same as before).

All intra-project imports are now absolute (e.g., `from ai.src.datasets.hdf5_dataset import ...`).

